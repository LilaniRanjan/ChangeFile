import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import CardContent from '@material-ui/core/CardContent';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import SaveIcon from '@material-ui/icons/Save';
import { Alert} from '@material-ui/lab';
import pharmacyService from "../services/pharmacy.service";
import Snackbar from '@material-ui/core/Snackbar';
import ClearIcon from '@material-ui/icons/Clear';
import {ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Paper from '@material-ui/core/Paper';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import Select from "@material-ui/core/Select";



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 60,
    padding:10
  }
}

export default class PharmacyUpdatePage extends Component {
   constructor(props){
     super(props);
     this.state ={
        id:'',
        title: '',
        price: '',
        description: '',
        avatarUrl: '',
        imageUrl: '',
        type: '',
        message: null,
        snackbaropen: false,
        open: false,
        colors:''
    }
    this.saveThing = this.saveThing.bind(this);
    this.loadPharmacyProduct = this.loadPharmacyProduct.bind(this);
   }


   

    onChange = (e) =>{
        this.setState({ [e.target.name]: e.target.value });
    }
        
    componentDidMount() {
        const id = this.props.match.params.id;
        console.log(id);
        if(id) {
          this.loadPharmacyProduct(id);
        }
        // console.log(this.match.props.id)
      }
      loadPharmacyProduct =(id) =>{
        pharmacyService.getMedicineById(id) 
        .then((res) => {
          let Product = res.data;
          this.setState({
            id:Product.id,
            title: Product.title,
            price: Product.price,
            description: Product.description,
            avatarUrl: Product.avatarUrl,
            imageUrl: Product.imageUrl,
            type: Product.type,
          })
                 
  
        });
  
      }

      handleClose = (event, reason) => {
        if (reason === "clickaway") {
          return;
        }
    
        this.setState({snackbaropen:false})
      };

      saveThing = (e) => {
    e.preventDefault();
    if(this.state.title && this.state.price && this.state.description && this.state.avatarUrl && this.state.imageUrl && this.state.type){ 
    let product = {title: this.state.title, price: this.state.price, description: this.state.description, avatarUrl: this.state.avatarUrl, imageUrl: this.state.imageUrl, type: this.state.type};
    pharmacyService.updateMedicineById(this.state.id, product)
        .then(res => {
          console.log(res);
          this.setState({snackbaropen:true, message:'Product update successfully', colors:'success'})
          setTimeout(()=> this.productList(), 3000)
        })
        .catch(error => {
          console.log(error);
          this.setState({snackbaropen:true, message:'fail', colors:'error'})
        });
      }else{
        this.setState({snackbaropen:true, message:'Updated fail', colors:'error'})
      }

    }


    handleSubmit(event) {
        alert('A name was submitted: ' + this.state.value);
        event.preventDefault();
    }

    productList =()=>{
      return this.props.history.push('/medicine');
    }

    handleChange = (event) => {
      this.setState({type: event.target.value})
    };

  render(){


    return(
      <>
        <div>
          <Snackbar open={this.state.snackbaropen} autoHideDuration={3000} onClose={this.handleClose} anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
            <Alert onClose={this.handleClose} severity={this.state.colors}>
              {this.state.message}
            </Alert>
          </Snackbar>
        </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          <ValidatorForm onSubmit={this.saveThing}>
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8} >
                <Paper style={style.cardsty} elevation={3}>
                  <CardActions>
                    <CardContent>
                    <h2 style={{float: 'left'}}><FontAwesomeIcon icon={faEdit}/>Update Pharmacy product</h2>
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="Title"
                            name="title"
                            type="text"
                            label="madicine's Title"
                            helperText="Enter madicine Title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="price"
                            name="price"
                            type="number"
                            label="madicine's price"
                            helperText="Enter madicine price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="description"
                            name="description"
                            type="text"
                            label="medicine's description"
                            helperText="about madicine"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          {/* <TextValidator
                            id="type"
                            name="type"
                            type="text"
                            label="medicine Type"
                            helperText="Enter medicine Type"
                            variant="outlined"
                            value={this.state.type} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          /> */}

                        <InputLabel id="Medicine_Type">Type</InputLabel>
                          <Select
                            labelId="Medicine_Type"
                            id="Medicine_Type"
                            value={this.state.type}
                            onChange={this.handleChange}
                            label="Type"
                          >
                            <MenuItem value={"Allergy"}>
                              <em>Allergy</em>
                            </MenuItem>
                            <MenuItem value={"Antibiotics"}>Antibiotics</MenuItem>
                            <MenuItem value={"Anti_Cancer"}>Anti_Cancer</MenuItem>
                            <MenuItem value={"Anti_Fungal"}>Anti_Fungal</MenuItem>
                            <MenuItem value={"Anxiety"}>Anxiety</MenuItem>
                            <MenuItem value={"Arthritis_Pain"}>Arthritis_Pain</MenuItem>
                            <MenuItem value={"Asthma"}>Asthma</MenuItem>
                            <MenuItem value={"Colic"}>Colic</MenuItem>
                            <MenuItem value={"Cushing"}>Cushing</MenuItem>
                            <MenuItem value={"Digestive_Tract"}>Digestive_Tract</MenuItem>
                            <MenuItem value={"Ear_Medications"}>Ear_Medications</MenuItem>
                            <MenuItem value={"Epilepsy"}>Epilepsy</MenuItem>
                            <MenuItem value={"Arthritis_Pain"}>Arthritis_Pain</MenuItem>
                          </Select>
                          <FormHelperText>Enter medicine Type</FormHelperText>
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="imageUrl"
                            name="imageUrl"
                            tye="Url"
                            label="madicine's imageUrl"
                            helperText="Enter madicine imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="avatarUrl"
                            name="avatarUrl"
                            tye="Url"
                            label="madicine's avatarUrl"
                            helperText="Enter madicine avatarUrl"
                            variant="outlined"
                            value={this.state.avatarUrl} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      </Grid>
                    </CardContent>
                  </CardActions>
                  <CardActions style={{float: 'right'}}>
                        <FormControl>
                          <Button type="submit" variant="contained" 
                          color="primary"
                          startIcon={<SaveIcon />}>
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        <FormControl>
                          <Button href="/admin" variant="contained" 
                          color="primary"
                          startIcon={<ClearIcon />}>
                            <span>Cancel</span>
                          </Button>
                        </FormControl>
                    </CardActions>
                    <br/>
                    <br/>
                    <br/>
                </Paper>
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            </ValidatorForm>
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
