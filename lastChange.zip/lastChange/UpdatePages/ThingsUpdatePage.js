import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import CardContent from '@material-ui/core/CardContent';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import TextField from '@material-ui/core/TextField';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Box from '@material-ui/core/Box';
import SaveIcon from '@material-ui/icons/Save';
import ListAltOutlinedIcon from '@material-ui/icons/ListAltOutlined';
import { Alert} from '@material-ui/lab';
import thingsService from "../services/things.service";
import Snackbar from '@material-ui/core/Snackbar';
import ClearIcon from '@material-ui/icons/Clear';
import {ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Paper from '@material-ui/core/Paper';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import Select from "@material-ui/core/Select";



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 60,
    padding:10
  }
}

export default class ThingsUpdatePage extends Component {
  constructor(props){
    super(props);
    this.state ={
        id:'',
        title: '',
        imageUrl: '',
        description: '',
        owner: '',
        price: '',
        type: '',
        pet:'',
        message: null,
        snackbaropen: false,
        open: false
   }
   this.saveThing = this.saveThing.bind(this);
   this.loadThingProduct = this.loadThingProduct.bind(this);
  }

  componentDidMount() {
    const id = this.props.match.params.id;
    console.log(id);
    if(id) {
      this.loadThingProduct(id);
    }
    // console.log(this.match.props.id)
  }
  loadThingProduct =(id) =>{
    thingsService.getProductById(id) 
    .then((res) => {
      let Product = res.data;
      this.setState({
        id:Product.id,
        title: Product.title,
        imageUrl: Product.imageUrl,
        description: Product.description,
        owner: Product.owner,
        price: Product.price,
        type: Product.type,
        pet: Product.pet,
        colors:''
      })
             

    });

  }

  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({snackbaropen:false})
  };


  saveThing = (e) => {
    e.preventDefault();
    if(this.state.title && this.state.imageUrl && this.state.description && this.state.owner && this.state.price && this.state.type && this.state.pet){ 
    let product = {title: this.state.title, imageUrl: this.state.imageUrl, description: this.state.description, owner: this.state.owner, price: this.state.price, type: this.state.type, pet: this.state.pet};
    thingsService.updateProduct(this.state.id, product)
        .then(res => {
          console.log(res);
          this.setState({snackbaropen:true, message:'Product update successfully', colors:'success'})
          setTimeout(()=> this.productList(), 3000)
        })
        .catch(error => {
          console.log(error);
          this.setState({snackbaropen:true, message:'fail', colors:'error'})
        });
      }else{
        this.setState({snackbaropen:true, message:'Thing Updated fail', colors:'error'})
      }
}

   onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });


   handleSubmit(event) {
       alert('A name was submitted: ' + this.state.value);
       event.preventDefault();
   }

   productList =()=>{
    return this.props.history.push('/thing');
  }

  handleChange = (event) => {
    this.setState({type: event.target.value})
  };

  handleChangePet = (e) => {
    this.setState({pet: e.target.value})
  };

  render(){

    return(
      <>

        <div>
          <Snackbar open={this.state.snackbaropen} autoHideDuration={3000} onClose={this.handleClose} anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
            <Alert onClose={this.handleClose} severity={this.state.colors}>
              {this.state.message}
            </Alert>
          </Snackbar>
        </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          <ValidatorForm onSubmit={this.saveThing}>
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8}>
                <Paper style={style.cardsty} elevation={3}>
                  <CardActions>
                    <CardContent>
                    <h2 style={{float: 'left'}}><FontAwesomeIcon icon={faEdit}/>Add New Thing</h2>
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="title"
                            name="title"
                            type="text"
                            label="Thing title"
                            helperText="Enter thing title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="description"
                            name="description"
                            type="text"
                            label="Thing description"
                            helperText="Enter thing description"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="owner"
                            name="owner"
                            type="text"
                            label="Thing owner"
                            helperText="Enter thing owner"
                            variant="outlined"
                            value={this.state.owner} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="price"
                            name="price"
                            type="number"
                            label="Thing price"
                            helperText="Enter thing price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          {/* <TextValidator
                            id="type"
                            name="type"
                            type="text"
                            label="Thing type"
                            helperText="Enter thing type"
                            variant="outlined"
                            value={this.state.type} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          /> */}

                        <InputLabel id="Things_Type">Type</InputLabel>
                          <Select
                            labelId="Things_Type"
                            id="Things_Type"
                            value={this.state.type}
                            onChange={this.handleChange}
                            label="Type"
                          >
                            <MenuItem value={"Bowls"}>
                              <em>Bowls</em>
                            </MenuItem>
                            <MenuItem value={"Collars"}>Collars</MenuItem>
                            <MenuItem value={"Toys"}>Toys</MenuItem>
                            <MenuItem value={"Training"}>Training</MenuItem>
                            <MenuItem value={"Kennels"}>Kennels</MenuItem>
                            <MenuItem value={"Grooming"}>Grooming</MenuItem>
                            <MenuItem value={"Shampoo"}>Shampoo</MenuItem>
                            <MenuItem value={"Odours"}>Odours</MenuItem>
                            <MenuItem value={"Multifunction"}>Multifunction</MenuItem>
                            <MenuItem value={"Cage"}>Cage</MenuItem>
                            <MenuItem value={"Mats"}>Mats</MenuItem>
                            <MenuItem value={"Harness"}>Harness</MenuItem>
                          </Select>
                          <FormHelperText>Enter things Type</FormHelperText>
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          {/* <TextValidator
                            id="pet"
                            name="pet"
                            type="text"
                            label="pet type"
                            helperText="Enter pet type"
                            variant="outlined"
                            value={this.state.pet} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          /> */}

                        <InputLabel id="pet">Pet</InputLabel>
                          <Select
                            labelId="pet"
                            id="pet"
                            value={this.state.pet} 
                            onChange={this.handleChangePet}
                            label="pet"
                          >
                            <MenuItem value={"dog"}>
                              <em>dog</em>
                            </MenuItem>
                            <MenuItem value={"cat"}>cat</MenuItem>
                            <MenuItem value={"parrot"}>parrot</MenuItem>
                          </Select>
                          <FormHelperText>Enter Pet Type</FormHelperText>
                        </FormControl>
                      </Grid>

                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="imageUrl"
                            name="imageUrl"
                            type="Url"
                            label="Thing's imageUrl"
                            helperText="Enter thing imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      </Grid>
                    </CardContent>
                  </CardActions>
                  <CardActions style={{float: 'right'}}>
                        <FormControl>
                          <Button type="submit" variant="contained"
                          startIcon={<SaveIcon />}
                          color="primary">
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        <FormControl>
                          <Button href="/admin" variant="contained"
                          color="primary" 
                          startIcon={<ClearIcon />}>
                            <span>Cancel</span>
                          </Button>
                        </FormControl>
                    </CardActions>
                    <br/>
                    <br/>
                    <br/>
                </Paper>
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            </ValidatorForm>
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
