import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import SaveIcon from '@material-ui/icons/Save';
import pharmacyService from "../services/pharmacy.service";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from "@material-ui/lab/Alert";
import ClearIcon from '@material-ui/icons/Clear';
import {ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Paper from '@material-ui/core/Paper';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import Select from "@material-ui/core/Select";



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 60,
    padding:50
  }
}

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default class AddPharmacy extends Component {
   constructor(props){
     super(props);
     this.state ={
        title: '',
        price: '',
        description: '',
        avatarUrl: '',
        imageUrl: '',
        type: '',
        message: null,
        snackbaropen: false,
        colors:'',
        type:''
    }
    this.saveThing = this.saveThing.bind(this);
   }


  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({snackbaropen:false})
  };

   saveThing = (e) => {
    e.preventDefault();
    if(this.state.title && this.state.price && this.state.description && this.state.avatarUrl && this.state.type){ 
    let thing = {title: this.state.title, price: this.state.price, description: this.state.description, avatarUrl: this.state.avatarUrl, imageUrl: this.state.imageUrl, type: this.state.type};
    pharmacyService.createMedicine(thing)
        .then(res => {
            this.setState({snackbaropen:true, message:'Product added successfully', colors:'success'})
        },
        (error)=>{
          this.setState({snackbaropen:true, message:'failed', colors:'error'})
        });
      }else{
        this.setState({snackbaropen:true, message:'Medicine added failed', colors:'error'})
      }
}

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });


    handleChange = (event) => {
      this.setState({type: event.target.value})
    };

  render(){

    return(
      <>

    <div>
      <Snackbar 
        open={this.state.snackbaropen} 
        autoHideDuration={3000} 
        onClose={this.handleClose} 
        anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
        <Alert onClose={this.handleClose} severity={this.state.colors}>
          {this.state.message}
        </Alert>
      </Snackbar>
    </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          <ValidatorForm onSubmit={this.saveThing}>
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8}>
              <Paper style={style.cardsty} elevation={3}>
                    <h2 style={{float: 'left'}}><FontAwesomeIcon icon={faEdit}/>Add New Pharmacy product</h2>
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="Title"
                            name="title"
                            type="text"
                            label="madicine's Title"
                            helperText="Enter madicine Title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="price"
                            name="price"
                            type="number"
                            label="madicine's price"
                            helperText="Enter madicine price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="description"
                            name="description"
                            type="text"
                            label="madicine's description"
                            helperText="about madicine"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                        <InputLabel id="Medicine_Type">Type</InputLabel>
                          <Select
                            labelId="Medicine_Type"
                            id="Medicine_Type"
                            value={this.state.type}
                            onChange={this.handleChange}
                            label="Type"
                          >
                            <MenuItem value={"Allergy"}>
                              <em>Allergy</em>
                            </MenuItem>
                            <MenuItem value={"Antibiotics"}>Antibiotics</MenuItem>
                            <MenuItem value={"Anti_Cancer"}>Anti_Cancer</MenuItem>
                            <MenuItem value={"Anti_Fungal"}>Anti_Fungal</MenuItem>
                            <MenuItem value={"Anxiety"}>Anxiety</MenuItem>
                            <MenuItem value={"Arthritis_Pain"}>Arthritis_Pain</MenuItem>
                            <MenuItem value={"Asthma"}>Asthma</MenuItem>
                            <MenuItem value={"Colic"}>Colic</MenuItem>
                            <MenuItem value={"Cushing"}>Cushing</MenuItem>
                            <MenuItem value={"Digestive_Tract"}>Digestive_Tract</MenuItem>
                            <MenuItem value={"Ear_Medications"}>Ear_Medications</MenuItem>
                            <MenuItem value={"Epilepsy"}>Epilepsy</MenuItem>
                            <MenuItem value={"Arthritis_Pain"}>Arthritis_Pain</MenuItem>
                          </Select>
                          <FormHelperText>Enter medicine Type</FormHelperText>
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="imageUrl"
                            name="imageUrl"
                            type="url"
                            label="madicine's imageUrl"
                            helperText="Enter madicine imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="avatarUrl"
                            name="avatarUrl"
                            type="url"
                            label="madicine's avatarUrl"
                            helperText="Enter madicine avatarUrl"
                            variant="outlined"
                            value={this.state.avatarUrl} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      </Grid>
                  <CardActions style={{float: 'right'}}>
                        <FormControl>
                          <Button type="submit" variant="contained" 
                          startIcon={<SaveIcon />}
                          color="primary">
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        <FormControl>
                          <Button href="/admin" variant="contained" 
                          startIcon={<ClearIcon />}
                          color="primary">
                            <span>Cancel</span>
                          </Button>
                        </FormControl>
                    </CardActions>
                    <br/>
                    <br/>
                    <br/>
                </Paper>
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            </ValidatorForm>
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
