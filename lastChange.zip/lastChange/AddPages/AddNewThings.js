import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import CardContent from '@material-ui/core/CardContent';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import SaveIcon from '@material-ui/icons/Save';
import thingsService from "../services/things.service";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from "@material-ui/lab/Alert";
import {ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import ClearIcon from '@material-ui/icons/Clear';
import Paper from '@material-ui/core/Paper';
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import Select from "@material-ui/core/Select";



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 60,
    padding:50
  }
}

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default class AddNewThings extends Component {
  constructor(props){
    super(props);
    this.state ={
      title: '',
      description: '',
      owner: '',
      price: '',
      type: '',
      pet: '',
      imageUrl:'',
      message: null,
      snackbaropen: false,
      open: false,
      colors:''
   }
   this.saveThing = this.saveThing.bind(this);
  }

  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({snackbaropen:false})
  };

  saveThing = (e) => {
    console.log('Hiiiiiiiiii');
   e.preventDefault();
   if(this.state.title && this.state.description && this.state.owner && this.state.price && this.state.type && this.state.pet && this.state.imageUrl){
   console.log("welcomeeeeeeeeee");
    let thing = {title: this.state.title, description: this.state.description, owner: this.state.owner, price: this.state.price, type: this.state.type, pet: this.state.pet, imageUrl: this.state.imageUrl};
   thingsService.createPetProducts(thing)
       .then(res => {
          this.setState({snackbaropen:true, message:'Thing added successfully', colors:'success'})
       },
        (error)=>{
          this.setState({snackbaropen:true, message:'failed', colors:'error'})
        });
  }else{
    this.setState({snackbaropen:true, message:'Thing added failed', colors:'error'})
  }
}

   onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });


    handleChange = (event) => {
        this.setState({type: event.target.value})
    };

    handleChangePet = (e) => {
      this.setState({pet: e.target.value})
  };

  render(){

    return(
      <>
        <div>
          <Snackbar open={this.state.snackbaropen} autoHideDuration={3000} onClose={this.handleClose} anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
            <Alert onClose={this.handleClose} severity={this.state.colors}>
              {this.state.message}
            </Alert>
          </Snackbar>
        </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8}>
                <Paper style={style.cardsty} elevation={3}>
                <ValidatorForm onSubmit={this.saveThing}>
                    <CardContent>
                      <h2 style={{float: 'left'}}><FontAwesomeIcon icon={faEdit}/>Add New Thing</h2>
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="title"
                            name="title"
                            type="text"
                            label="Thing title"
                            helperText="Enter thing title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                            fullWidth
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="description"
                            name="description"
                            type="text"
                            label="Thing description"
                            helperText="Enter thing description"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="owner"
                            name="owner"
                            type="text"
                            label="Thing owner"
                            helperText="Enter thing owner"
                            variant="outlined"
                            value={this.state.owner} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="price"
                            name="price"
                            type="number"
                            label="Thing price"
                            helperText="Enter thing price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          {/* <TextValidator
                            id="type"
                            name="type"
                            type="text"
                            label="Thing type"
                            helperText="Enter thing type"
                            variant="outlined"
                            value={this.state.type} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          /> */}

                        <InputLabel id="Things_Type">Type</InputLabel>
                          <Select
                            labelId="Things_Type"
                            id="Things_Type"
                            value={this.state.type}
                            onChange={this.handleChange}
                            label="Type"
                          >
                            <MenuItem value={"Bowls"}>
                              <em>Bowls</em>
                            </MenuItem>
                            <MenuItem value={"Collars"}>Collars</MenuItem>
                            <MenuItem value={"Toys"}>Toys</MenuItem>
                            <MenuItem value={"Training"}>Training</MenuItem>
                            <MenuItem value={"Kennels"}>Kennels</MenuItem>
                            <MenuItem value={"Grooming"}>Grooming</MenuItem>
                            <MenuItem value={"Shampoo"}>Shampoo</MenuItem>
                            <MenuItem value={"Odours"}>Odours</MenuItem>
                            <MenuItem value={"Multifunction"}>Multifunction</MenuItem>
                            <MenuItem value={"Cage"}>Cage</MenuItem>
                            <MenuItem value={"Mats"}>Mats</MenuItem>
                            <MenuItem value={"Harness"}>Harness</MenuItem>
                          </Select>
                          <FormHelperText>Enter things Type</FormHelperText>
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          {/* <TextValidator
                            id="pet"
                            name="pet"
                            type="text"
                            label="pet type"
                            helperText="Enter pet type"
                            variant="outlined"
                            value={this.state.pet} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          /> */}

                        <InputLabel id="pet">Pet</InputLabel>
                          <Select
                            labelId="pet"
                            id="pet"
                            value={this.state.pet} 
                            onChange={this.handleChangePet}
                            label="pet"
                          >
                            <MenuItem value={"dog"}>
                              <em>dog</em>
                            </MenuItem>
                            <MenuItem value={"cat"}>cat</MenuItem>
                            <MenuItem value={"parrot"}>parrot</MenuItem>
                          </Select>
                          <FormHelperText>Enter Pet Type</FormHelperText>
                        </FormControl>
                      </Grid>

                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextValidator
                            id="imageUrl"
                            name="imageUrl"
                            type="url"
                            label="Thing's imageUrl"
                            helperText="Enter thing imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                            fullWidth
                            validators={['required']}
                            errorMessages={['This fieled is required']}
                          />
                        </FormControl>
                      </Grid>

                      </Grid>
                    </CardContent>
                  <CardActions style={{float: 'right'}}>
                        <FormControl>
                          <Button type="submit" variant="contained"
                          startIcon={<SaveIcon />}
                          color="primary">
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        <FormControl>
                          <Button href="/admin" variant="contained" 
                          startIcon={<ClearIcon />}
                          color="primary">
                            <span>Cancel</span>
                          </Button>
                        </FormControl>
                    </CardActions>
                    <br/>
                    <br/>
                    <br/>
                    </ValidatorForm>
                </Paper>
                
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
