import React,{useEffect} from "react";
import PharmacyProductCard from "./PharmacyProductCard";
import { Grid} from "@material-ui/core";
import pharmacyService from "../services/pharmacy.service";
import { Alert, AlertTitle } from "@material-ui/lab";

const PharmacyContent = (props) => {
  const [medicine, setMedicine] = React.useState([])
 console.log(props);
  useEffect(() => {
    pharmacyService.getMedicineByType(props.med)

    .then(
      response => {
        console.log(response)
        setMedicine(response.data)
      },
      error => {
        console.log(error)
        setMedicine(
          (error.response && error.response.data) ||
            error.message ||
            error.toString()
        )
      }
    );
    
  }, [])


 

  const petMakerCard = (response) => {
    return (
      <>
        <Grid item xs={12} sm={4}>
          
          <PharmacyProductCard {...response} />
        </Grid>
      </>
    );
  };

  if (medicine) {
    return (
      <>
        <Grid container spacing={3}>
            {medicine.map((response) => petMakerCard(response))}
          
        </Grid>
      </>
    );
  }else{
    return (
      <>
        <Alert severity="info">
          <AlertTitle>  <b style={{float: 'center'}}> **No Availables** </b> </AlertTitle>
      </Alert>
      </>
    )
  }
  
  
};

export default PharmacyContent;